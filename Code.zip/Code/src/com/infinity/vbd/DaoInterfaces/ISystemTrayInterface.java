/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.infinity.vbd.DaoInterfaces;

import com.infinity.vbd.Beans.TrayIconBean;

/**
 *
 * @author Shubham
 */
public interface ISystemTrayInterface {
    public TrayIconBean addSystemTray();
}
