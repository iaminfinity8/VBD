/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.infinity.vbd.DaoInterfaces;

/**
 *
 * @author Akash
 */
public interface MainClassInterface {
    public void addTrayIcon();
    public void createDummyStage();
    public void startRecognition();
    public void showSettingsScene();
    public void exitApp();
}
