/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.infinity.vbd.DaoInterfaces;

/**
 *
 * @author Akash
 */
public interface NotificationInterface {
    public void showRecognitionStartedNotification();
    public void showMeaningNotification(String word,String meaning);
}
